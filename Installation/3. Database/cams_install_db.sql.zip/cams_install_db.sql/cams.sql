-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2017 at 03:36 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cams`
--
DROP DATABASE IF EXISTS cams;
CREATE DATABASE IF NOT EXISTS cams;
use cams;
CREATE USER IF NOT EXISTS 'cams'@'localhost' identified by 'cams';
GRANT ALL ON cams.* to 'cams'@'localhost';
-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_economic_situations`
--

CREATE TABLE `cams_assessment_economic_situations` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q3_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_houshold_profiles`
--

CREATE TABLE `cams_assessment_houshold_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q2_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_11` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_12` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_13` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_14` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_impairment_types`
--

CREATE TABLE `cams_assessment_impairment_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q5_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_independence_participations`
--

CREATE TABLE `cams_assessment_independence_participations` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q7_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q7_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q7_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q7_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q7_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q7_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q7_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q7_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_interviews`
--

CREATE TABLE `cams_assessment_interviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `wc_assessment_id` int(10) UNSIGNED NOT NULL,
  `assess_interview_diagnosis_qn_1` text COLLATE utf8_unicode_ci,
  `assess_interview_diagnosis_qn_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_physical_issues_qn_1` text COLLATE utf8_unicode_ci,
  `assess_interview_physical_issues_qn_2` text COLLATE utf8_unicode_ci,
  `assess_interview_physical_issues_qn_3` text COLLATE utf8_unicode_ci,
  `assess_interview_physical_issues_qn_3_describe` text COLLATE utf8_unicode_ci,
  `assess_interview_physical_issues_qn_4` text COLLATE utf8_unicode_ci,
  `assess_interview_physical_issues_qn_4_describe` text COLLATE utf8_unicode_ci,
  `assess_interview_physical_issues_qn_5` text COLLATE utf8_unicode_ci,
  `assess_interview_physical_issues_qn_6` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_lifestyle_env_qn_1_describe` text COLLATE utf8_unicode_ci,
  `assess_interview_lifestyle_env_qn_1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_lifestyle_env_qn_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_lifestyle_env_qn_3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_lifestyle_env_qn_4` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_lifestyle_env_qn_5` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_lifestyle_env_qn_6` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_lifestyle_env_qn_7` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_lifestyle_env_qn_7_describe` text COLLATE utf8_unicode_ci,
  `assess_interview_existing_wheelchair_qn_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_existing_wheelchair_qn_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_existing_wheelchair_qn_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_existing_wheelchair_qn_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_existing_wheelchair_qn_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assess_interview_existing_wheelchair_qn_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_item_needs`
--

CREATE TABLE `cams_assessment_item_needs` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q10_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_11` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_12` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_13` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_14` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_15` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_16` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_17` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_18` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_19` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_20` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_21` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_22` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_23` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_24` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_25` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q10_26` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_nutritions`
--

CREATE TABLE `cams_assessment_nutritions` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q6_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q6_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q6_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_protections`
--

CREATE TABLE `cams_assessment_protections` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q9_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q9_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q9_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q9_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q9_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q9_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q9_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q9_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_psychosocials`
--

CREATE TABLE `cams_assessment_psychosocials` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q8_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q8_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q8_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q8_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q8_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q8_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q8_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q8_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_referrals`
--

CREATE TABLE `cams_assessment_referrals` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q11_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q11_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q11_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q11_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q11_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q11_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_assessment_vulnerability_types`
--

CREATE TABLE `cams_assessment_vulnerability_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q4_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_audits`
--

CREATE TABLE `cams_audits` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `page` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activity_date` date DEFAULT NULL,
  `log_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_budget_activities`
--

CREATE TABLE `cams_budget_activities` (
  `id` int(10) UNSIGNED NOT NULL,
  `activity_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` double DEFAULT '0',
  `currency` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `donor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provision_limit` int(11) DEFAULT '0',
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Available',
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_camps`
--

CREATE TABLE `cams_camps` (
  `id` int(10) UNSIGNED NOT NULL,
  `reg_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `camp_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region_id` int(10) UNSIGNED DEFAULT NULL,
  `district_id` int(10) UNSIGNED DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'working',
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_camps`
--

INSERT INTO `cams_camps` (`id`, `reg_no`, `camp_name`, `description`, `address`, `tel`, `region_id`, `district_id`, `status`, `auth_status`, `created_by`, `updated_by`, `auth_by`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Nduta', NULL, NULL, NULL, 1, 1, 'working', 'pending', NULL, NULL, NULL, '2017-03-10 02:34:20', '2017-03-10 02:34:20'),
(2, NULL, 'Mtendeli', NULL, NULL, NULL, 1, 2, 'working', 'pending', NULL, NULL, NULL, '2017-03-10 02:34:22', '2017-03-10 02:34:22');

-- --------------------------------------------------------

--
-- Table structure for table `cams_cash_provisions`
--

CREATE TABLE `cams_cash_provisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `provision_date` date NOT NULL,
  `provided_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `camp_id` int(10) UNSIGNED DEFAULT NULL,
  `activity_id` int(10) UNSIGNED NOT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_cash_provision_clients`
--

CREATE TABLE `cams_cash_provision_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `activity_id` int(10) UNSIGNED NOT NULL,
  `amount` int(10) UNSIGNED NOT NULL,
  `provision_id` int(10) UNSIGNED NOT NULL,
  `provision_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_clients`
--

CREATE TABLE `cams_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `hai_reg_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `age_score` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `spouse_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `care_giver` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `child_care_giver` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `origin_id` int(10) UNSIGNED DEFAULT NULL,
  `camp_id` int(10) UNSIGNED DEFAULT NULL,
  `date_arrival` date DEFAULT NULL,
  `present_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `females_total` int(11) DEFAULT NULL,
  `males_total` int(11) DEFAULT NULL,
  `household_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ration_card_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assistance_received` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `problem_specification` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `share_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hh_relation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_client_cases`
--

CREATE TABLE `cams_client_cases` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `open_date` date DEFAULT NULL,
  `case_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descriptions` text COLLATE utf8_unicode_ci,
  `initial_action` text COLLATE utf8_unicode_ci,
  `feedback` text COLLATE utf8_unicode_ci,
  `planning` text COLLATE utf8_unicode_ci,
  `case_worker_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vol` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Open Case',
  `client_id` int(10) UNSIGNED NOT NULL,
  `camp_id` int(10) UNSIGNED DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_client_informations`
--

CREATE TABLE `cams_client_informations` (
  `id` int(10) UNSIGNED NOT NULL,
  `referral_id` int(10) UNSIGNED NOT NULL,
  `cl_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_age` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_nationality` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_id_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_care_giver` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_care_giver_relationship` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_care_giver_contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_child_separated` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cl_care_giver_informed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_client_needs`
--

CREATE TABLE `cams_client_needs` (
  `id` int(10) UNSIGNED NOT NULL,
  `need_id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'No',
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_client_progresses`
--

CREATE TABLE `cams_client_progresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `open_date` date DEFAULT NULL,
  `subjective_information` text COLLATE utf8_unicode_ci,
  `objective_information` text COLLATE utf8_unicode_ci,
  `analysis` text COLLATE utf8_unicode_ci,
  `planning` text COLLATE utf8_unicode_ci,
  `case_worker_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Opened',
  `client_id` int(10) UNSIGNED NOT NULL,
  `camp_id` int(10) UNSIGNED DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_client_referrals`
--

CREATE TABLE `cams_client_referrals` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referral_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referral_date` date DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Open',
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_client_vulnerability_codes`
--

CREATE TABLE `cams_client_vulnerability_codes` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `code_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_countries`
--

CREATE TABLE `cams_countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `country_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_countries`
--

INSERT INTO `cams_countries` (`id`, `country_name`, `country_code`, `auth_status`, `created_by`, `updated_by`, `auth_by`, `created_at`, `updated_at`) VALUES
(1, 'Tanzania', NULL, 'pending', NULL, NULL, NULL, '2017-03-10 02:34:13', '2017-03-10 02:34:13');

-- --------------------------------------------------------

--
-- Table structure for table `cams_departments`
--

CREATE TABLE `cams_departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `department_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_districts`
--

CREATE TABLE `cams_districts` (
  `id` int(10) UNSIGNED NOT NULL,
  `district_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `region_id` int(10) UNSIGNED NOT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_districts`
--

INSERT INTO `cams_districts` (`id`, `district_name`, `region_id`, `auth_status`, `created_by`, `updated_by`, `auth_by`, `created_at`, `updated_at`) VALUES
(1, 'Kibondo', 1, 'pending', NULL, NULL, NULL, '2017-03-10 02:34:19', '2017-03-10 02:34:19'),
(2, 'Kakonko', 1, 'pending', NULL, NULL, NULL, '2017-03-10 02:34:22', '2017-03-10 02:34:22');

-- --------------------------------------------------------

--
-- Table structure for table `cams_dump_cash_distributions`
--

CREATE TABLE `cams_dump_cash_distributions` (
  `id` int(10) UNSIGNED NOT NULL,
  `names` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `m` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `t` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `origin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_arrival` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vul_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_dump_clients`
--

CREATE TABLE `cams_dump_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `unique_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `names` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_of_parents` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_of_spouse` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `m` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `t` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `origin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_arrival` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `present_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ration_card_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vul_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vul_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vul_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vul_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vul_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_dump_items_disbursements`
--

CREATE TABLE `cams_dump_items_disbursements` (
  `id` int(10) UNSIGNED NOT NULL,
  `names` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `m` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `t` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `origin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_arrival` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vul_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quantity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_forms`
--

CREATE TABLE `cams_forms` (
  `id` int(10) UNSIGNED NOT NULL,
  `form_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_forms_fields`
--

CREATE TABLE `cams_forms_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `group_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `values` text COLLATE utf8_unicode_ci,
  `rule` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_forms_group_fields`
--

CREATE TABLE `cams_forms_group_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `form_id` int(10) UNSIGNED NOT NULL,
  `group_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_functional_assessments`
--

CREATE TABLE `cams_functional_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_hand_simulations`
--

CREATE TABLE `cams_hand_simulations` (
  `id` int(10) UNSIGNED NOT NULL,
  `p_assessment_id` int(10) UNSIGNED NOT NULL,
  `perlvis` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `perlvis_0` text COLLATE utf8_unicode_ci,
  `truck` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `truck_1` text COLLATE utf8_unicode_ci,
  `head` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `head_2` text COLLATE utf8_unicode_ci,
  `l_hip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `l_hip_3` text COLLATE utf8_unicode_ci,
  `r_hip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `r_hip_4` text COLLATE utf8_unicode_ci,
  `thighs` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thighs_5` text COLLATE utf8_unicode_ci,
  `l_knee` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `l_knee_6` text COLLATE utf8_unicode_ci,
  `r_knee` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `r_knee_7` text COLLATE utf8_unicode_ci,
  `l_ankle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `l_ankle_8` text COLLATE utf8_unicode_ci,
  `r_ankle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `r_ankle_9` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_home_assessments`
--

CREATE TABLE `cams_home_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `case_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linked_case_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assessment_date` date DEFAULT NULL,
  `needs_description` text COLLATE utf8_unicode_ci,
  `findings` text COLLATE utf8_unicode_ci,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `recommendations` text COLLATE utf8_unicode_ci,
  `final_decision` text COLLATE utf8_unicode_ci,
  `case_worker_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_coordinator` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `organization` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_houshold_profiles`
--

CREATE TABLE `cams_houshold_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `household_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `household_head_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `household_head_age` int(11) DEFAULT NULL,
  `spouse_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `males_total` int(11) DEFAULT NULL,
  `females_total` int(11) DEFAULT NULL,
  `child_under_5` int(11) DEFAULT NULL,
  `child_between_6_18` int(11) DEFAULT NULL,
  `number_women` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_inclusion_assessments`
--

CREATE TABLE `cams_inclusion_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `assessor_id` int(10) UNSIGNED NOT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_inclusion_medical_histories`
--

CREATE TABLE `cams_inclusion_medical_histories` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `med_history_info_qn_1` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_1_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_2` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_2_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_history_info_qn_3_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_history_info_qn_4_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_history_info_qn_5_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_history_info_qn_6_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_history_info_qn_7_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_history_info_qn_8_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_history_info_qn_9_remark` text COLLATE utf8_unicode_ci,
  `med_history_info_qn_10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_history_info_qn_10_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_inventory_receiveds`
--

CREATE TABLE `cams_inventory_receiveds` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_received` date DEFAULT NULL,
  `donor_ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `received_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `receiving_officer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `onward_delivery` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_items_categories`
--

CREATE TABLE `cams_items_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Available',
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_items_disbursements`
--

CREATE TABLE `cams_items_disbursements` (
  `id` int(10) UNSIGNED NOT NULL,
  `disbursements_date` date NOT NULL,
  `disbursements_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `camp_id` int(10) UNSIGNED DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_items_disbursement_items`
--

CREATE TABLE `cams_items_disbursement_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `distribution_date` date DEFAULT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `distribution_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_items_inventories`
--

CREATE TABLE `cams_items_inventories` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `redistribution_limit` int(11) DEFAULT '0',
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_item_receiveds`
--

CREATE TABLE `cams_item_receiveds` (
  `id` int(10) UNSIGNED NOT NULL,
  `received_id` int(10) UNSIGNED DEFAULT NULL,
  `item_id` int(10) UNSIGNED DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_i_a_cognitions`
--

CREATE TABLE `cams_i_a_cognitions` (
  `id` int(10) UNSIGNED NOT NULL,
  `inclusion_id` int(10) UNSIGNED NOT NULL,
  `attention` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `concentration` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `problem_solving` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `orientation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sequencing` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_i_a_motor_skills`
--

CREATE TABLE `cams_i_a_motor_skills` (
  `id` int(10) UNSIGNED NOT NULL,
  `inclusion_id` int(10) UNSIGNED NOT NULL,
  `gross_motor_skills` text COLLATE utf8_unicode_ci,
  `rom` text COLLATE utf8_unicode_ci,
  `muscle_strength` text COLLATE utf8_unicode_ci,
  `tone` text COLLATE utf8_unicode_ci,
  `endurance` text COLLATE utf8_unicode_ci,
  `balance` text COLLATE utf8_unicode_ci,
  `lying_sitting` text COLLATE utf8_unicode_ci,
  `sitting` text COLLATE utf8_unicode_ci,
  `squatting` text COLLATE utf8_unicode_ci,
  `standing` text COLLATE utf8_unicode_ci,
  `posture` text COLLATE utf8_unicode_ci,
  `head_control` text COLLATE utf8_unicode_ci,
  `trunk_control` text COLLATE utf8_unicode_ci,
  `spinal_deformities` text COLLATE utf8_unicode_ci,
  `symmetry` text COLLATE utf8_unicode_ci,
  `subluxation` text COLLATE utf8_unicode_ci,
  `hand_function` text COLLATE utf8_unicode_ci,
  `coordination` text COLLATE utf8_unicode_ci,
  `eye_hand_coordination` text COLLATE utf8_unicode_ci,
  `tripod_grasp` text COLLATE utf8_unicode_ci,
  `power_grasp` text COLLATE utf8_unicode_ci,
  `cylindrical_grasp` text COLLATE utf8_unicode_ci,
  `release` text COLLATE utf8_unicode_ci,
  `bilateral_use_hands` text COLLATE utf8_unicode_ci,
  `hand_dominance` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_i_a_sensory_abilities`
--

CREATE TABLE `cams_i_a_sensory_abilities` (
  `id` int(10) UNSIGNED NOT NULL,
  `inclusion_id` int(10) UNSIGNED NOT NULL,
  `vision` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hearing` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `light_touch` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deep_touch` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `proprioception` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stereognosis` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temperature` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_migrations`
--

CREATE TABLE `cams_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_migrations`
--

INSERT INTO `cams_migrations` (`id`, `migration`, `batch`) VALUES
(1261, '2014_10_12_000000_create_users_table', 1),
(1262, '2014_10_12_100000_create_password_resets_table', 1),
(1263, '2017_01_14_072224_entrust_setup_tables', 1),
(1264, '2017_01_14_081_create_origins_table', 1),
(1265, '2017_01_19_144559_create_departments_table', 1),
(1266, '2017_01_19_144819_create_countries_table', 1),
(1267, '2017_01_19_144922_create_regions_table', 1),
(1268, '2017_01_19_144932_create_districts_table', 1),
(1269, '2017_01_19_144953_create_camps_table', 1),
(1270, '2017_01_19_144955_create_clients_table', 1),
(1271, '2017_01_19_151758_create_p_s_n_code_categories_table', 1),
(1272, '2017_01_19_151759_create_p_s_n_codes_table', 1),
(1273, '2017_01_20_100418_create_client_vulnerability_codes_table', 1),
(1274, '2017_01_20_103359_create_houshold_profiles_table', 1),
(1275, '2017_01_23_142828_create_vulnerability_assessments_table', 1),
(1276, '2017_01_23_145703_create_assessment_houshold_profiles_table', 1),
(1277, '2017_01_23_151245_create_assessment_economic_situations_table', 1),
(1278, '2017_01_23_153008_create_assessment_vulnerability_types_table', 1),
(1279, '2017_01_23_153833_create_assessment_impairment_types_table', 1),
(1280, '2017_01_23_154716_create_assessment_nutritions_table', 1),
(1281, '2017_01_23_155027_create_assessment_independence_participations_table', 1),
(1282, '2017_01_23_155747_create_assessment_psychosocials_table', 1),
(1283, '2017_01_23_160016_create_assessment_item_needs_table', 1),
(1284, '2017_01_23_160053_create_assessment_protections_table', 1),
(1285, '2017_01_23_180034_create_i_a_sensory_abilities_table', 1),
(1286, '2017_01_23_180217_create_i_a_motor_skills_table', 1),
(1287, '2017_01_24_031217_create_i_a_cognitions_table', 1),
(1288, '2017_01_26_232704_create_items_categories_table', 1),
(1289, '2017_01_26_232705_create_items_inventories_table', 1),
(1290, '2017_01_26_232740_create_items_disbursements_table', 1),
(1291, '2017_01_26_232741_create_items_disbursement_items_table', 1),
(1292, '2017_01_27_054311_create_inventory_receiveds_table', 1),
(1293, '2017_01_27_054312_create_item_receiveds_table', 1),
(1294, '2017_01_27_164135_create_forms_table', 1),
(1295, '2017_01_27_164647_create_forms_group_fields_table', 1),
(1296, '2017_01_27_164700_create_forms_fields_table', 1),
(1297, '2017_01_29_072501_create_assessment_referrals_table', 1),
(1298, '2017_02_01_002744_create_home_assessments_table', 1),
(1299, '2017_02_04_225954_create_rehabilitations_table', 1),
(1300, '2017_02_05_205315_create_wheel_chair_assessments_table', 1),
(1301, '2017_02_07_152032_create_assessment_interviews_table', 1),
(1302, '2017_02_07_153514_create_physcal_assessments_table', 1),
(1303, '2017_02_07_163248_create_hand_simulations_table', 1),
(1304, '2017_02_07_163453_create_take_measurements_table', 1),
(1305, '2017_02_08_164349_create_paediatric_assessments_table', 1),
(1306, '2017_02_08_165640_create_paediatric_assessment_histories_table', 1),
(1307, '2017_02_08_170534_create_paediatric_child_histories_table', 1),
(1308, '2017_02_08_171034_create_paediatric_child_growths_table', 1),
(1309, '2017_02_08_173038_create_paediatric_child_inspections_table', 1),
(1310, '2017_02_08_173323_create_paediatric_child_inspection_results_table', 1),
(1311, '2017_02_09_124355_create_functional_assessments_table', 1),
(1312, '2017_02_09_221915_create_client_cases_table', 1),
(1313, '2017_02_13_031932_create_inclusion_assessments_table', 1),
(1314, '2017_02_13_032405_create_inclusion_medical_histories_table', 1),
(1315, '2017_02_13_032802_create_mpc_part_as_table', 1),
(1316, '2017_02_13_032847_create_mpc_part_bs_table', 1),
(1317, '2017_02_13_050532_create_mpc_part_cs_table', 1),
(1318, '2017_02_13_050942_create_mpc_part_ds_table', 1),
(1319, '2017_02_13_051015_create_mpc_part_fs_table', 1),
(1320, '2017_02_13_051128_create_mpc_part_es_table', 1),
(1321, '2017_02_13_051214_create_mpc_performance_areas_table', 1),
(1322, '2017_02_13_051245_create_mpc_contexts_table', 1),
(1323, '2017_02_13_051300_create_mpc_swots_table', 1),
(1324, '2017_02_13_051349_create_mpc_long_rehabs_table', 1),
(1325, '2017_02_13_051415_create_mpc_part_a_rom_lowers_table', 1),
(1326, '2017_02_13_051428_create_mpc_part_a_rom_uppers_table', 1),
(1327, '2017_02_13_051439_create_mpc_part_a_postures_table', 1),
(1328, '2017_02_13_051456_create_mpc_part_a_moving_patterns_table', 1),
(1329, '2017_02_13_051530_create_mpc_part_b_body_senses_table', 1),
(1330, '2017_02_13_161820_create_mpc_short_rehabs_table', 1),
(1331, '2017_02_14_114429_create_audits_table', 1),
(1332, '2017_02_19_081949_create_client_progresses_table', 1),
(1333, '2017_02_20_003348_create_client_referrals_table', 1),
(1334, '2017_02_20_004928_create_receiving_agencies_table', 1),
(1335, '2017_02_20_005230_create_client_informations_table', 1),
(1336, '2017_02_20_011033_create_referral_reasons_table', 1),
(1337, '2017_02_20_011901_create_referral_service_requesteds_table', 1),
(1338, '2017_02_20_023310_create_requested_services_table', 1),
(1339, '2017_02_20_040013_create_referring_agencies_table', 1),
(1340, '2017_02_20_103647_create_progress_notes_table', 1),
(1341, '2017_02_27_100555_create_budget_activities_table', 1),
(1342, '2017_02_27_111849_create_cash_provisions_table', 1),
(1343, '2017_02_27_113312_create_cash_provision_clients_table', 1),
(1344, '2017_02_27_214047_create_post_cash_assessments_table', 1),
(1345, '2017_02_28_080325_create_p_c_demographic_details_table', 1),
(1346, '2017_02_28_183035_create_p_c_cash_withdrawals_table', 1),
(1347, '2017_02_28_184747_create_p_c_physically_receiving_cashes_table', 1),
(1348, '2017_02_28_190740_create_p_c_communal_relations_table', 1),
(1349, '2017_02_28_190952_create_p_c_cash_usages_table', 1),
(1350, '2017_02_28_191237_create_p_c_categories_table', 1),
(1351, '2017_02_28_191421_create_p_c_cash_usage_categories_table', 1),
(1352, '2017_03_02_030643_create_need_categories_table', 1),
(1353, '2017_03_02_030709_create_needs_table', 1),
(1354, '2017_03_02_030727_create_client_needs_table', 1),
(1355, '2017_03_08_191109_create_dump_clients_table', 1),
(1356, '2017_03_09_083640_create_dump_items_disbursements_table', 1),
(1357, '2017_03_09_083752_create_dump_cash_distributions_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_contexts`
--

CREATE TABLE `cams_mpc_contexts` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_context_1` text COLLATE utf8_unicode_ci,
  `mpc_context_2` text COLLATE utf8_unicode_ci,
  `mpc_context_3_remark` text COLLATE utf8_unicode_ci,
  `mpc_context_4` text COLLATE utf8_unicode_ci,
  `mpc_context_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_5_remark` text COLLATE utf8_unicode_ci,
  `mpc_context_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_6_remark` text COLLATE utf8_unicode_ci,
  `mpc_context_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_9_remark` text COLLATE utf8_unicode_ci,
  `mpc_context_10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_11` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_12` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_13` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_14` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_15_remark` text COLLATE utf8_unicode_ci,
  `mpc_context_16` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_context_16_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_long_rehabs`
--

CREATE TABLE `cams_mpc_long_rehabs` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_long_rehab_1_remark` text COLLATE utf8_unicode_ci,
  `mpc_long_rehab_2_remark` text COLLATE utf8_unicode_ci,
  `mpc_long_rehab_3_remark` text COLLATE utf8_unicode_ci,
  `mpc_long_rehab_4_remark` text COLLATE utf8_unicode_ci,
  `mpc_long_rehab_5_remark` text COLLATE utf8_unicode_ci,
  `mpc_long_rehab_6_remark` text COLLATE utf8_unicode_ci,
  `mpc_long_rehab_7_remark` text COLLATE utf8_unicode_ci,
  `mpc_long_rehab_8_remark` text COLLATE utf8_unicode_ci,
  `mpc_long_rehab_9_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_as`
--

CREATE TABLE `cams_mpc_part_as` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_a_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_1_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_2_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_8_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_10_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_11` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_12` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_13` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_14` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_15` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_16` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_16_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_a_moving_patterns`
--

CREATE TABLE `cams_mpc_part_a_moving_patterns` (
  `id` int(10) UNSIGNED NOT NULL,
  `mpc_part_a_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_a_42_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_42` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_43` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_44` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_45` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_46` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_47` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_48` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_49` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_50` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_51` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_52` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_53` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_a_postures`
--

CREATE TABLE `cams_mpc_part_a_postures` (
  `id` int(10) UNSIGNED NOT NULL,
  `mpc_part_a_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_a_17` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_18` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_19` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_20` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_21` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_22` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_23` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_24` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_25_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_26_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_27_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_28_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_29_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_30` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_31_remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_32` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_33` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_34` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_35` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_35_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_a_36` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_37` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_38` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_39` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_40` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_a_41_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_a_rom_lowers`
--

CREATE TABLE `cams_mpc_part_a_rom_lowers` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `lower_limb_row_1` text COLLATE utf8_unicode_ci,
  `lower_limb_row_2` text COLLATE utf8_unicode_ci,
  `lower_limb_row_3` text COLLATE utf8_unicode_ci,
  `lower_limb_row_4` text COLLATE utf8_unicode_ci,
  `lower_limb_row_5` text COLLATE utf8_unicode_ci,
  `lower_limb_row_6` text COLLATE utf8_unicode_ci,
  `lower_limb_row_7` text COLLATE utf8_unicode_ci,
  `lower_limb_row_8` text COLLATE utf8_unicode_ci,
  `lower_limb_row_9` text COLLATE utf8_unicode_ci,
  `lower_limb_row_10` text COLLATE utf8_unicode_ci,
  `lower_limb_row_11` text COLLATE utf8_unicode_ci,
  `lower_limb_row_12` text COLLATE utf8_unicode_ci,
  `lower_limb_row_13` text COLLATE utf8_unicode_ci,
  `lower_limb_row_14` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_a_rom_uppers`
--

CREATE TABLE `cams_mpc_part_a_rom_uppers` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `upper_limb_row_1` text COLLATE utf8_unicode_ci,
  `upper_limb_row_2` text COLLATE utf8_unicode_ci,
  `upper_limb_row_3` text COLLATE utf8_unicode_ci,
  `upper_limb_row_4` text COLLATE utf8_unicode_ci,
  `upper_limb_row_5` text COLLATE utf8_unicode_ci,
  `upper_limb_row_6` text COLLATE utf8_unicode_ci,
  `upper_limb_row_7` text COLLATE utf8_unicode_ci,
  `upper_limb_row_8` text COLLATE utf8_unicode_ci,
  `upper_limb_row_9` text COLLATE utf8_unicode_ci,
  `upper_limb_row_10` text COLLATE utf8_unicode_ci,
  `upper_limb_row_11` text COLLATE utf8_unicode_ci,
  `upper_limb_row_12` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_bs`
--

CREATE TABLE `cams_mpc_part_bs` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_b_1` text COLLATE utf8_unicode_ci,
  `mpc_qn_b_1_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_b_2` text COLLATE utf8_unicode_ci,
  `mpc_qn_b_2_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_b_3_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_b_4` text COLLATE utf8_unicode_ci,
  `mpc_qn_b_27_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_b_28` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_b_body_senses`
--

CREATE TABLE `cams_mpc_part_b_body_senses` (
  `id` int(10) UNSIGNED NOT NULL,
  `mpc_part_b_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_b_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_11` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_12` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_13` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_14` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_15` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_16` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_17` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_18` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_19` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_20` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_21` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_22` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_23` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_24` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_25` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_b_26` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_cs`
--

CREATE TABLE `cams_mpc_part_cs` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_c_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_c_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_c_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_c_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_c_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_c_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_c_7_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_ds`
--

CREATE TABLE `cams_mpc_part_ds` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_d_1` text COLLATE utf8_unicode_ci,
  `mpc_qn_d_2` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_es`
--

CREATE TABLE `cams_mpc_part_es` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_e_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_e_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_e_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_e_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_e_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_e_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_e_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpc_qn_e_8` text COLLATE utf8_unicode_ci,
  `mpc_qn_e_8_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_part_fs`
--

CREATE TABLE `cams_mpc_part_fs` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_qn_f_1` text COLLATE utf8_unicode_ci,
  `mpc_qn_f_2_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_f_3` text COLLATE utf8_unicode_ci,
  `mpc_qn_f_4_remark` text COLLATE utf8_unicode_ci,
  `mpc_qn_f_5` text COLLATE utf8_unicode_ci,
  `mpc_qn_f_6` text COLLATE utf8_unicode_ci,
  `mpc_qn_f_7_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_performance_areas`
--

CREATE TABLE `cams_mpc_performance_areas` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_perf_area_1` text COLLATE utf8_unicode_ci,
  `mpc_perf_area_2` text COLLATE utf8_unicode_ci,
  `mpc_perf_area_3` text COLLATE utf8_unicode_ci,
  `mpc_perf_area_4` text COLLATE utf8_unicode_ci,
  `mpc_perf_area_4_remark` text COLLATE utf8_unicode_ci,
  `mpc_perf_area_5` text COLLATE utf8_unicode_ci,
  `mpc_perf_area_5_remark` text COLLATE utf8_unicode_ci,
  `mpc_perf_area_6` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_short_rehabs`
--

CREATE TABLE `cams_mpc_short_rehabs` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_short_rehab_1_remark` text COLLATE utf8_unicode_ci,
  `mpc_short_rehab_2_remark` text COLLATE utf8_unicode_ci,
  `mpc_short_rehab_3_remark` text COLLATE utf8_unicode_ci,
  `mpc_short_rehab_4_remark` text COLLATE utf8_unicode_ci,
  `mpc_short_rehab_5_remark` text COLLATE utf8_unicode_ci,
  `mpc_short_rehab_6_remark` text COLLATE utf8_unicode_ci,
  `mpc_short_rehab_7_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_mpc_swots`
--

CREATE TABLE `cams_mpc_swots` (
  `id` int(10) UNSIGNED NOT NULL,
  `incl_assessment_id` int(10) UNSIGNED NOT NULL,
  `mpc_swot_1_remark` text COLLATE utf8_unicode_ci,
  `mpc_swot_2_remark` text COLLATE utf8_unicode_ci,
  `mpc_swot_3_remark` text COLLATE utf8_unicode_ci,
  `mpc_swot_4_remark` text COLLATE utf8_unicode_ci,
  `mpc_swot_5_remark` text COLLATE utf8_unicode_ci,
  `mpc_swot_6_remark` text COLLATE utf8_unicode_ci,
  `mpc_swot_7_remark` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_needs`
--

CREATE TABLE `cams_needs` (
  `id` int(10) UNSIGNED NOT NULL,
  `need_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_needs`
--

INSERT INTO `cams_needs` (`id`, `need_name`, `category_id`, `auth_status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Needs for referral', 2, 'pending', NULL, NULL, '2017-03-10 02:34:07', '2017-03-10 02:34:07'),
(2, 'Health', 2, 'pending', NULL, NULL, '2017-03-10 02:34:07', '2017-03-10 02:34:07'),
(3, 'Psychosocial', 2, 'pending', NULL, NULL, '2017-03-10 02:34:07', '2017-03-10 02:34:07'),
(4, 'Child protection', 2, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(5, 'Shelter', 2, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(6, 'NFIs', 2, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(7, 'Assisting devices', 1, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(8, 'Crutches', 1, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(9, 'Toilet chair', 1, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(10, 'Urine flaks:', 1, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(11, 'White cane', 1, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(12, 'Walking aids', 1, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(13, 'Wheel chairs', 1, 'pending', NULL, NULL, '2017-03-10 02:34:08', '2017-03-10 02:34:08'),
(14, 'Incontinent kit', 1, 'pending', NULL, NULL, '2017-03-10 02:34:09', '2017-03-10 02:34:09'),
(15, 'Bedpan', 1, 'pending', NULL, NULL, '2017-03-10 02:34:09', '2017-03-10 02:34:09'),
(16, 'Needs for specific Items', 1, 'pending', NULL, NULL, '2017-03-10 02:34:09', '2017-03-10 02:34:09'),
(17, 'Mattresses', 1, 'pending', NULL, NULL, '2017-03-10 02:34:09', '2017-03-10 02:34:09'),
(18, 'Blanket', 1, 'pending', NULL, NULL, '2017-03-10 02:34:09', '2017-03-10 02:34:09'),
(19, 'Stove', 1, 'pending', NULL, NULL, '2017-03-10 02:34:09', '2017-03-10 02:34:09'),
(20, 'Toileteries', 1, 'pending', NULL, NULL, '2017-03-10 02:34:09', '2017-03-10 02:34:09'),
(21, 'Diapers', 1, 'pending', NULL, NULL, '2017-03-10 02:34:09', '2017-03-10 02:34:09'),
(22, 'Jarrican', 1, 'pending', NULL, NULL, '2017-03-10 02:34:10', '2017-03-10 02:34:10'),
(23, 'Clothing', 1, 'pending', NULL, NULL, '2017-03-10 02:34:10', '2017-03-10 02:34:10'),
(24, 'Dignity kit men', 1, 'pending', NULL, NULL, '2017-03-10 02:34:10', '2017-03-10 02:34:10'),
(25, 'Dignity kit women', 1, 'pending', NULL, NULL, '2017-03-10 02:34:10', '2017-03-10 02:34:10'),
(26, 'Underwear', 1, 'pending', NULL, NULL, '2017-03-10 02:34:10', '2017-03-10 02:34:10'),
(27, 'Needs for protection items', 1, 'pending', NULL, NULL, '2017-03-10 02:34:10', '2017-03-10 02:34:10'),
(28, 'Flashlight', 1, 'pending', NULL, NULL, '2017-03-10 02:34:11', '2017-03-10 02:34:11'),
(29, 'Whistle', 1, 'pending', NULL, NULL, '2017-03-10 02:34:11', '2017-03-10 02:34:11'),
(30, 'Radio', 1, 'pending', NULL, NULL, '2017-03-10 02:34:11', '2017-03-10 02:34:11'),
(31, 'Wheelchair', 1, 'pending', NULL, NULL, '2017-03-10 02:34:12', '2017-03-10 02:34:12'),
(32, 'Functional Assessments', 1, 'pending', NULL, NULL, '2017-03-10 02:34:12', '2017-03-10 02:34:12');

-- --------------------------------------------------------

--
-- Table structure for table `cams_need_categories`
--

CREATE TABLE `cams_need_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_need_categories`
--

INSERT INTO `cams_need_categories` (`id`, `category_name`, `auth_status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Needs of Items', 'pending', NULL, NULL, '2017-03-10 02:34:06', '2017-03-10 02:34:06'),
(2, 'Referral', 'pending', NULL, NULL, '2017-03-10 02:34:06', '2017-03-10 02:34:06');

-- --------------------------------------------------------

--
-- Table structure for table `cams_origins`
--

CREATE TABLE `cams_origins` (
  `id` int(10) UNSIGNED NOT NULL,
  `origin_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_paediatric_assessments`
--

CREATE TABLE `cams_paediatric_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rational_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unique_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `home_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `father_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_job` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_age` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `mother_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_job` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_age` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `permanent_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `school_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `school_reasons` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` int(10) UNSIGNED NOT NULL,
  `domicile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `communication` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_children` int(11) DEFAULT '0',
  `total_children_alive` int(11) DEFAULT '0',
  `total_children_dead` int(11) DEFAULT '0',
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_paediatric_assessment_histories`
--

CREATE TABLE `cams_paediatric_assessment_histories` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `place_born` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_pregnant_complications` text COLLATE utf8_unicode_ci,
  `mother_birth_complications` text COLLATE utf8_unicode_ci,
  `child_birth_condition` text COLLATE utf8_unicode_ci,
  `mother_labor_days` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `was_child_cry` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_paediatric_child_growths`
--

CREATE TABLE `cams_paediatric_child_growths` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `sitting` text COLLATE utf8_unicode_ci,
  `crowing` text COLLATE utf8_unicode_ci,
  `standing` text COLLATE utf8_unicode_ci,
  `walking` text COLLATE utf8_unicode_ci,
  `talking` text COLLATE utf8_unicode_ci,
  `child_self_expression` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_paediatric_child_histories`
--

CREATE TABLE `cams_paediatric_child_histories` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `child_complications` text COLLATE utf8_unicode_ci,
  `child_complication_1` text COLLATE utf8_unicode_ci,
  `child_complication_2` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_paediatric_child_inspections`
--

CREATE TABLE `cams_paediatric_child_inspections` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `area` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `investigation_type` text COLLATE utf8_unicode_ci,
  `results` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_paediatric_child_inspection_results`
--

CREATE TABLE `cams_paediatric_child_inspection_results` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `child_ability` text COLLATE utf8_unicode_ci,
  `child_special_need` text COLLATE utf8_unicode_ci,
  `activities` text COLLATE utf8_unicode_ci,
  `long_term_plan` text COLLATE utf8_unicode_ci,
  `short_term_plan` text COLLATE utf8_unicode_ci,
  `consultation` text COLLATE utf8_unicode_ci,
  `provider_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider_designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider_date` date DEFAULT NULL,
  `source_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_date` date DEFAULT NULL,
  `centre_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_password_resets`
--

CREATE TABLE `cams_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_permissions`
--

CREATE TABLE `cams_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_permissions`
--

INSERT INTO `cams_permissions` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'create', 'Create', 'create', '2017-03-10 02:33:48', '2017-03-10 02:33:48'),
(2, 'edit', 'Edit', 'Update and modify data', '2017-03-10 02:33:48', '2017-03-10 02:33:48'),
(3, 'viewer', 'Viewer', 'viewer data only', '2017-03-10 02:33:48', '2017-03-10 02:33:48'),
(4, 'reports', NULL, 'viewer reports', '2017-03-10 02:33:49', '2017-03-10 02:33:49'),
(5, 'authorize', 'Authorize', 'Authorize Data imported', '2017-03-10 02:33:49', '2017-03-10 02:33:49'),
(6, 'inventory', 'inventory', 'Access to NFIs Inventory ', '2017-03-10 02:33:50', '2017-03-10 02:33:50'),
(7, 'delete', 'delete', 'delete Data', '2017-03-10 02:33:50', '2017-03-10 02:33:50'),
(8, 'backup', 'backup', 'Access to data export and import', '2017-03-10 02:33:51', '2017-03-10 02:33:51');

-- --------------------------------------------------------

--
-- Table structure for table `cams_permission_role`
--

CREATE TABLE `cams_permission_role` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_permission_role`
--

INSERT INTO `cams_permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 4),
(1, 5),
(2, 1),
(2, 3),
(2, 4),
(2, 5),
(3, 1),
(3, 2),
(3, 3),
(3, 4),
(3, 5),
(4, 2),
(4, 4),
(5, 3),
(5, 4),
(6, 1),
(6, 3),
(6, 4),
(6, 5),
(7, 1),
(7, 3),
(7, 4),
(7, 5),
(8, 1),
(8, 4),
(8, 5);

-- --------------------------------------------------------

--
-- Table structure for table `cams_physical_assessments`
--

CREATE TABLE `cams_physical_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `wc_assessment_id` int(10) UNSIGNED NOT NULL,
  `physical_assess_presence_risk_qn_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_presence_risk_qn_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_presence_risk_qn_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_presence_risk_qn_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_presence_risk_qn_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_presence_risk_qn_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_method_of_pushing_qn_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_method_of_pushing_qn_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_method_of_pushing_qn_2_describe` text COLLATE utf8_unicode_ci,
  `physical_assess_sitting_posture_without_support_qn_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_pelvis_hip_posture_screen_qn_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_pelvis_hip_posture_screen_qn_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_pelvis_hip_posture_screen_qn_2_angle` text COLLATE utf8_unicode_ci,
  `physical_assess_pelvis_hip_posture_screen_qn_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_assess_pelvis_hip_posture_screen_qn_3_angle` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_post_cash_assessments`
--

CREATE TABLE `cams_post_cash_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `camp_id` int(10) UNSIGNED NOT NULL,
  `district_id` int(10) UNSIGNED NOT NULL,
  `interview_date` date DEFAULT NULL,
  `interview_start_time` time DEFAULT NULL,
  `interview_end_time` time DEFAULT NULL,
  `organisation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enumerator_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `respondent_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enumerator_observations` text COLLATE utf8_unicode_ci,
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_progress_notes`
--

CREATE TABLE `cams_progress_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `open_date` date DEFAULT NULL,
  `subjective_information` text COLLATE utf8_unicode_ci,
  `objective_information` text COLLATE utf8_unicode_ci,
  `analysis` text COLLATE utf8_unicode_ci,
  `planning` text COLLATE utf8_unicode_ci,
  `case_worker_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Open Notice',
  `client_id` int(10) UNSIGNED NOT NULL,
  `camp_id` int(10) UNSIGNED DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_c_cash_usages`
--

CREATE TABLE `cams_p_c_cash_usages` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q6_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q6_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q6_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q6_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_c_cash_usage_categories`
--

CREATE TABLE `cams_p_c_cash_usage_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `usage_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `currency` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_c_cash_withdrawals`
--

CREATE TABLE `cams_p_c_cash_withdrawals` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q3_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q3_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_c_categories`
--

CREATE TABLE `cams_p_c_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_p_c_categories`
--

INSERT INTO `cams_p_c_categories` (`id`, `category_name`, `created_at`, `updated_at`) VALUES
(1, 'Food', '2017-03-10 02:34:04', '2017-03-10 02:34:04'),
(2, 'Gift/Share', '2017-03-10 02:34:04', '2017-03-10 02:34:04'),
(3, 'Livestock', '2017-03-10 02:34:04', '2017-03-10 02:34:04'),
(4, 'Business Investment', '2017-03-10 02:34:04', '2017-03-10 02:34:04'),
(5, 'Water', '2017-03-10 02:34:05', '2017-03-10 02:34:05'),
(6, 'Medical', '2017-03-10 02:34:05', '2017-03-10 02:34:05'),
(7, 'Education', '2017-03-10 02:34:05', '2017-03-10 02:34:05'),
(8, 'Debt repayment', '2017-03-10 02:34:05', '2017-03-10 02:34:05'),
(9, 'Transport', '2017-03-10 02:34:05', '2017-03-10 02:34:05'),
(10, 'Rent or shelter materials', '2017-03-10 02:34:05', '2017-03-10 02:34:05'),
(11, 'Agriculture inputs', '2017-03-10 02:34:05', '2017-03-10 02:34:05'),
(12, 'Household items', '2017-03-10 02:34:06', '2017-03-10 02:34:06'),
(13, 'Fuel', '2017-03-10 02:34:06', '2017-03-10 02:34:06'),
(14, 'Clothes/Shoes', '2017-03-10 02:34:06', '2017-03-10 02:34:06'),
(15, 'Labour- shelter', '2017-03-10 02:34:06', '2017-03-10 02:34:06'),
(16, 'Labour- Agriculture', '2017-03-10 02:34:06', '2017-03-10 02:34:06'),
(17, 'Saved/in hand', '2017-03-10 02:34:06', '2017-03-10 02:34:06'),
(18, 'Other', '2017-03-10 02:34:06', '2017-03-10 02:34:06');

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_c_communal_relations`
--

CREATE TABLE `cams_p_c_communal_relations` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q5_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q5_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_c_demographic_details`
--

CREATE TABLE `cams_p_c_demographic_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q2_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_2` int(11) DEFAULT NULL,
  `q2_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q2_6` int(11) DEFAULT NULL,
  `q2_7` int(11) DEFAULT NULL,
  `q2_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_c_physically_receiving_cashes`
--

CREATE TABLE `cams_p_c_physically_receiving_cashes` (
  `id` int(10) UNSIGNED NOT NULL,
  `assessment_id` int(10) UNSIGNED NOT NULL,
  `q4_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_10_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_11` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_12` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_13` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_14` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_15` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_16` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_17` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_18` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_19` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_20` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_21` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q4_22` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_s_n_codes`
--

CREATE TABLE `cams_p_s_n_codes` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `definition` text COLLATE utf8_unicode_ci,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `for_reporting` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'No',
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_p_s_n_code_categories`
--

CREATE TABLE `cams_p_s_n_code_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `definition` text COLLATE utf8_unicode_ci,
  `for_reporting` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'No',
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_receiving_agencies`
--

CREATE TABLE `cams_receiving_agencies` (
  `id` int(10) UNSIGNED NOT NULL,
  `referral_id` int(10) UNSIGNED NOT NULL,
  `rec_organisation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rec_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rec_contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rec_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rec_location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_referral_reasons`
--

CREATE TABLE `cams_referral_reasons` (
  `id` int(10) UNSIGNED NOT NULL,
  `referral_id` int(10) UNSIGNED NOT NULL,
  `client_referral_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_referral_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_referral_info_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_referral_status_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_referral_service_requesteds`
--

CREATE TABLE `cams_referral_service_requesteds` (
  `id` int(10) UNSIGNED NOT NULL,
  `referral_id` int(10) UNSIGNED NOT NULL,
  `service_request` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_referring_agencies`
--

CREATE TABLE `cams_referring_agencies` (
  `id` int(10) UNSIGNED NOT NULL,
  `referral_id` int(10) UNSIGNED NOT NULL,
  `ref_organisation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref_contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref_location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_regions`
--

CREATE TABLE `cams_regions` (
  `id` int(10) UNSIGNED NOT NULL,
  `country_id` int(10) UNSIGNED DEFAULT NULL,
  `region_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_regions`
--

INSERT INTO `cams_regions` (`id`, `country_id`, `region_name`, `auth_status`, `created_by`, `updated_by`, `auth_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Kigoma', 'pending', NULL, NULL, NULL, '2017-03-10 02:34:15', '2017-03-10 02:34:15');

-- --------------------------------------------------------

--
-- Table structure for table `cams_rehabilitations`
--

CREATE TABLE `cams_rehabilitations` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_requested_services`
--

CREATE TABLE `cams_requested_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `requested_id` int(10) UNSIGNED NOT NULL,
  `service_request` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_roles`
--

CREATE TABLE `cams_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_roles`
--

INSERT INTO `cams_roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'inputer', 'Inputer', 'User for inputing data to the system', '2017-03-10 02:33:47', '2017-03-10 02:33:47'),
(2, 'viewer', 'Viewer', 'User for viewing data', '2017-03-10 02:33:47', '2017-03-10 02:33:47'),
(3, 'authorizer', 'Authorizer', 'User for Authorize data', '2017-03-10 02:33:47', '2017-03-10 02:33:47'),
(4, 'admin', 'Administrator', 'Super System Administrator', '2017-03-10 02:33:47', '2017-03-10 02:33:47'),
(5, 'inventory', 'NFIs and Cash Distribution', 'Access to inventory', '2017-03-10 02:33:48', '2017-03-10 02:33:48');

-- --------------------------------------------------------

--
-- Table structure for table `cams_role_user`
--

CREATE TABLE `cams_role_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_role_user`
--

INSERT INTO `cams_role_user` (`user_id`, `role_id`) VALUES
(1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `cams_take_measurements`
--

CREATE TABLE `cams_take_measurements` (
  `id` int(10) UNSIGNED NOT NULL,
  `p_assessment_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_users`
--

CREATE TABLE `cams_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `camp_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Normal',
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Active',
  `locked` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_logout` datetime DEFAULT NULL,
  `last_success_login` datetime DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cams_users`
--

INSERT INTO `cams_users` (`id`, `full_name`, `phone`, `email`, `address`, `department_id`, `camp_id`, `designation`, `level`, `status`, `locked`, `username`, `password`, `last_login`, `last_logout`, `last_success_login`, `profile_image`, `auth_status`, `created_by`, `updated_by`, `auth_by`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'System Administrator', NULL, 'info@helpage.org', NULL, NULL, NULL, NULL, 'Super', 'Active', 0, 'admin', '$2y$10$jg0nkd6hnUR2SoCEwHm69ed29EGEhOYccPD8BR3rRV8nsocVst4zW', NULL, NULL, NULL, NULL, 'pending', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cams_vulnerability_assessments`
--

CREATE TABLE `cams_vulnerability_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `q1_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q1_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q1_3` int(10) UNSIGNED DEFAULT NULL,
  `q1_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `q1_5` date DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cams_wheel_chair_assessments`
--

CREATE TABLE `cams_wheel_chair_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `assessor_id` int(10) UNSIGNED NOT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cams_assessment_economic_situations`
--
ALTER TABLE `cams_assessment_economic_situations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_economic_situations_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_houshold_profiles`
--
ALTER TABLE `cams_assessment_houshold_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_houshold_profiles_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_impairment_types`
--
ALTER TABLE `cams_assessment_impairment_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_impairment_types_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_independence_participations`
--
ALTER TABLE `cams_assessment_independence_participations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_independence_participations_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_interviews`
--
ALTER TABLE `cams_assessment_interviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_interviews_wc_assessment_id_foreign` (`wc_assessment_id`);

--
-- Indexes for table `cams_assessment_item_needs`
--
ALTER TABLE `cams_assessment_item_needs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_item_needs_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_nutritions`
--
ALTER TABLE `cams_assessment_nutritions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_nutritions_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_protections`
--
ALTER TABLE `cams_assessment_protections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_protections_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_psychosocials`
--
ALTER TABLE `cams_assessment_psychosocials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_psychosocials_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_referrals`
--
ALTER TABLE `cams_assessment_referrals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_referrals_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_assessment_vulnerability_types`
--
ALTER TABLE `cams_assessment_vulnerability_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_vulnerability_types_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_audits`
--
ALTER TABLE `cams_audits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_budget_activities`
--
ALTER TABLE `cams_budget_activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_camps`
--
ALTER TABLE `cams_camps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `camps_region_id_foreign` (`region_id`),
  ADD KEY `camps_district_id_foreign` (`district_id`);

--
-- Indexes for table `cams_cash_provisions`
--
ALTER TABLE `cams_cash_provisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cash_provisions_camp_id_foreign` (`camp_id`),
  ADD KEY `cash_provisions_activity_id_foreign` (`activity_id`);

--
-- Indexes for table `cams_cash_provision_clients`
--
ALTER TABLE `cams_cash_provision_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cash_provision_clients_client_id_foreign` (`client_id`),
  ADD KEY `cash_provision_clients_provision_id_foreign` (`provision_id`),
  ADD KEY `cash_provision_clients_activity_id_foreign` (`activity_id`);

--
-- Indexes for table `cams_clients`
--
ALTER TABLE `cams_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clients_origin_id_foreign` (`origin_id`),
  ADD KEY `clients_camp_id_foreign` (`camp_id`);

--
-- Indexes for table `cams_client_cases`
--
ALTER TABLE `cams_client_cases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_cases_client_id_foreign` (`client_id`),
  ADD KEY `client_cases_camp_id_foreign` (`camp_id`);

--
-- Indexes for table `cams_client_informations`
--
ALTER TABLE `cams_client_informations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_informations_referral_id_foreign` (`referral_id`);

--
-- Indexes for table `cams_client_needs`
--
ALTER TABLE `cams_client_needs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_needs_need_id_foreign` (`need_id`),
  ADD KEY `client_needs_client_id_foreign` (`client_id`),
  ADD KEY `client_needs_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_client_progresses`
--
ALTER TABLE `cams_client_progresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_progresses_client_id_foreign` (`client_id`),
  ADD KEY `client_progresses_camp_id_foreign` (`camp_id`);

--
-- Indexes for table `cams_client_referrals`
--
ALTER TABLE `cams_client_referrals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_referrals_client_id_foreign` (`client_id`);

--
-- Indexes for table `cams_client_vulnerability_codes`
--
ALTER TABLE `cams_client_vulnerability_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_vulnerability_codes_client_id_foreign` (`client_id`);

--
-- Indexes for table `cams_countries`
--
ALTER TABLE `cams_countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_departments`
--
ALTER TABLE `cams_departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_districts`
--
ALTER TABLE `cams_districts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `districts_region_id_foreign` (`region_id`),
  ADD KEY `districts_district_name_index` (`district_name`);

--
-- Indexes for table `cams_dump_cash_distributions`
--
ALTER TABLE `cams_dump_cash_distributions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_dump_clients`
--
ALTER TABLE `cams_dump_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_dump_items_disbursements`
--
ALTER TABLE `cams_dump_items_disbursements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_forms`
--
ALTER TABLE `cams_forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_forms_fields`
--
ALTER TABLE `cams_forms_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_forms_group_fields`
--
ALTER TABLE `cams_forms_group_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_functional_assessments`
--
ALTER TABLE `cams_functional_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `functional_assessments_client_id_foreign` (`client_id`);

--
-- Indexes for table `cams_hand_simulations`
--
ALTER TABLE `cams_hand_simulations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hand_simulations_p_assessment_id_foreign` (`p_assessment_id`);

--
-- Indexes for table `cams_home_assessments`
--
ALTER TABLE `cams_home_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `home_assessments_client_id_foreign` (`client_id`);

--
-- Indexes for table `cams_houshold_profiles`
--
ALTER TABLE `cams_houshold_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `houshold_profiles_client_id_foreign` (`client_id`);

--
-- Indexes for table `cams_inclusion_assessments`
--
ALTER TABLE `cams_inclusion_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inclusion_assessments_client_id_foreign` (`client_id`);

--
-- Indexes for table `cams_inclusion_medical_histories`
--
ALTER TABLE `cams_inclusion_medical_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inclusion_medical_histories_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_inventory_receiveds`
--
ALTER TABLE `cams_inventory_receiveds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_items_categories`
--
ALTER TABLE `cams_items_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `items_categories_category_name_unique` (`category_name`);

--
-- Indexes for table `cams_items_disbursements`
--
ALTER TABLE `cams_items_disbursements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_disbursements_camp_id_foreign` (`camp_id`);

--
-- Indexes for table `cams_items_disbursement_items`
--
ALTER TABLE `cams_items_disbursement_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_disbursement_items_client_id_foreign` (`client_id`),
  ADD KEY `items_disbursement_items_item_id_foreign` (`item_id`),
  ADD KEY `items_disbursement_items_distribution_id_foreign` (`distribution_id`);

--
-- Indexes for table `cams_items_inventories`
--
ALTER TABLE `cams_items_inventories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_inventories_category_id_foreign` (`category_id`);

--
-- Indexes for table `cams_item_receiveds`
--
ALTER TABLE `cams_item_receiveds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_receiveds_received_id_foreign` (`received_id`),
  ADD KEY `item_receiveds_item_id_foreign` (`item_id`);

--
-- Indexes for table `cams_i_a_cognitions`
--
ALTER TABLE `cams_i_a_cognitions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_i_a_motor_skills`
--
ALTER TABLE `cams_i_a_motor_skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_i_a_sensory_abilities`
--
ALTER TABLE `cams_i_a_sensory_abilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_migrations`
--
ALTER TABLE `cams_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_mpc_contexts`
--
ALTER TABLE `cams_mpc_contexts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_contexts_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_long_rehabs`
--
ALTER TABLE `cams_mpc_long_rehabs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_long_rehabs_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_part_as`
--
ALTER TABLE `cams_mpc_part_as`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_as_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_part_a_moving_patterns`
--
ALTER TABLE `cams_mpc_part_a_moving_patterns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_a_moving_patterns_mpc_part_a_id_foreign` (`mpc_part_a_id`);

--
-- Indexes for table `cams_mpc_part_a_postures`
--
ALTER TABLE `cams_mpc_part_a_postures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_a_postures_mpc_part_a_id_foreign` (`mpc_part_a_id`);

--
-- Indexes for table `cams_mpc_part_a_rom_lowers`
--
ALTER TABLE `cams_mpc_part_a_rom_lowers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_a_rom_lowers_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_part_a_rom_uppers`
--
ALTER TABLE `cams_mpc_part_a_rom_uppers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_a_rom_uppers_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_part_bs`
--
ALTER TABLE `cams_mpc_part_bs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_bs_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_part_b_body_senses`
--
ALTER TABLE `cams_mpc_part_b_body_senses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_b_body_senses_mpc_part_b_id_foreign` (`mpc_part_b_id`);

--
-- Indexes for table `cams_mpc_part_cs`
--
ALTER TABLE `cams_mpc_part_cs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_cs_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_part_ds`
--
ALTER TABLE `cams_mpc_part_ds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_ds_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_part_es`
--
ALTER TABLE `cams_mpc_part_es`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_es_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_part_fs`
--
ALTER TABLE `cams_mpc_part_fs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_part_fs_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_performance_areas`
--
ALTER TABLE `cams_mpc_performance_areas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_performance_areas_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_short_rehabs`
--
ALTER TABLE `cams_mpc_short_rehabs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_short_rehabs_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_mpc_swots`
--
ALTER TABLE `cams_mpc_swots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpc_swots_incl_assessment_id_foreign` (`incl_assessment_id`);

--
-- Indexes for table `cams_needs`
--
ALTER TABLE `cams_needs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `needs_category_id_foreign` (`category_id`);

--
-- Indexes for table `cams_need_categories`
--
ALTER TABLE `cams_need_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_origins`
--
ALTER TABLE `cams_origins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `origins_origin_name_unique` (`origin_name`);

--
-- Indexes for table `cams_paediatric_assessments`
--
ALTER TABLE `cams_paediatric_assessments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `paediatric_assessments_unique_number_unique` (`unique_number`),
  ADD KEY `paediatric_assessments_client_id_foreign` (`client_id`);

--
-- Indexes for table `cams_paediatric_assessment_histories`
--
ALTER TABLE `cams_paediatric_assessment_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paediatric_assessment_histories_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_paediatric_child_growths`
--
ALTER TABLE `cams_paediatric_child_growths`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paediatric_child_growths_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_paediatric_child_histories`
--
ALTER TABLE `cams_paediatric_child_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paediatric_child_histories_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_paediatric_child_inspections`
--
ALTER TABLE `cams_paediatric_child_inspections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paediatric_child_inspections_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_paediatric_child_inspection_results`
--
ALTER TABLE `cams_paediatric_child_inspection_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paediatric_child_inspection_results_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_password_resets`
--
ALTER TABLE `cams_password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `cams_permissions`
--
ALTER TABLE `cams_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `cams_permission_role`
--
ALTER TABLE `cams_permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `cams_physical_assessments`
--
ALTER TABLE `cams_physical_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `physical_assessments_wc_assessment_id_foreign` (`wc_assessment_id`);

--
-- Indexes for table `cams_post_cash_assessments`
--
ALTER TABLE `cams_post_cash_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_cash_assessments_client_id_foreign` (`client_id`),
  ADD KEY `post_cash_assessments_district_id_foreign` (`district_id`),
  ADD KEY `post_cash_assessments_camp_id_foreign` (`camp_id`);

--
-- Indexes for table `cams_progress_notes`
--
ALTER TABLE `cams_progress_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `progress_notes_client_id_foreign` (`client_id`),
  ADD KEY `progress_notes_camp_id_foreign` (`camp_id`);

--
-- Indexes for table `cams_p_c_cash_usages`
--
ALTER TABLE `cams_p_c_cash_usages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_c_cash_usages_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_p_c_cash_usage_categories`
--
ALTER TABLE `cams_p_c_cash_usage_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_c_cash_usage_categories_usage_id_foreign` (`usage_id`),
  ADD KEY `p_c_cash_usage_categories_category_id_foreign` (`category_id`);

--
-- Indexes for table `cams_p_c_cash_withdrawals`
--
ALTER TABLE `cams_p_c_cash_withdrawals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_c_cash_withdrawals_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_p_c_categories`
--
ALTER TABLE `cams_p_c_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_p_c_communal_relations`
--
ALTER TABLE `cams_p_c_communal_relations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_c_communal_relations_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_p_c_demographic_details`
--
ALTER TABLE `cams_p_c_demographic_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_c_demographic_details_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_p_c_physically_receiving_cashes`
--
ALTER TABLE `cams_p_c_physically_receiving_cashes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_c_physically_receiving_cashes_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `cams_p_s_n_codes`
--
ALTER TABLE `cams_p_s_n_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_s_n_codes_category_id_foreign` (`category_id`);

--
-- Indexes for table `cams_p_s_n_code_categories`
--
ALTER TABLE `cams_p_s_n_code_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_receiving_agencies`
--
ALTER TABLE `cams_receiving_agencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `receiving_agencies_referral_id_foreign` (`referral_id`);

--
-- Indexes for table `cams_referral_reasons`
--
ALTER TABLE `cams_referral_reasons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `referral_reasons_referral_id_foreign` (`referral_id`);

--
-- Indexes for table `cams_referral_service_requesteds`
--
ALTER TABLE `cams_referral_service_requesteds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `referral_service_requesteds_referral_id_foreign` (`referral_id`);

--
-- Indexes for table `cams_referring_agencies`
--
ALTER TABLE `cams_referring_agencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `referring_agencies_referral_id_foreign` (`referral_id`);

--
-- Indexes for table `cams_regions`
--
ALTER TABLE `cams_regions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `regions_country_id_foreign` (`country_id`);

--
-- Indexes for table `cams_rehabilitations`
--
ALTER TABLE `cams_rehabilitations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cams_requested_services`
--
ALTER TABLE `cams_requested_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requested_services_requested_id_foreign` (`requested_id`);

--
-- Indexes for table `cams_roles`
--
ALTER TABLE `cams_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `cams_role_user`
--
ALTER TABLE `cams_role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `cams_take_measurements`
--
ALTER TABLE `cams_take_measurements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `take_measurements_p_assessment_id_foreign` (`p_assessment_id`);

--
-- Indexes for table `cams_users`
--
ALTER TABLE `cams_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- Indexes for table `cams_vulnerability_assessments`
--
ALTER TABLE `cams_vulnerability_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vulnerability_assessments_client_id_foreign` (`client_id`);

--
-- Indexes for table `cams_wheel_chair_assessments`
--
ALTER TABLE `cams_wheel_chair_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wheel_chair_assessments_client_id_foreign` (`client_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cams_assessment_economic_situations`
--
ALTER TABLE `cams_assessment_economic_situations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_houshold_profiles`
--
ALTER TABLE `cams_assessment_houshold_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_impairment_types`
--
ALTER TABLE `cams_assessment_impairment_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_independence_participations`
--
ALTER TABLE `cams_assessment_independence_participations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_interviews`
--
ALTER TABLE `cams_assessment_interviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_item_needs`
--
ALTER TABLE `cams_assessment_item_needs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_nutritions`
--
ALTER TABLE `cams_assessment_nutritions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_protections`
--
ALTER TABLE `cams_assessment_protections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_psychosocials`
--
ALTER TABLE `cams_assessment_psychosocials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_referrals`
--
ALTER TABLE `cams_assessment_referrals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_assessment_vulnerability_types`
--
ALTER TABLE `cams_assessment_vulnerability_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_audits`
--
ALTER TABLE `cams_audits`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_budget_activities`
--
ALTER TABLE `cams_budget_activities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_camps`
--
ALTER TABLE `cams_camps`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cams_cash_provisions`
--
ALTER TABLE `cams_cash_provisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_cash_provision_clients`
--
ALTER TABLE `cams_cash_provision_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_clients`
--
ALTER TABLE `cams_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_client_cases`
--
ALTER TABLE `cams_client_cases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_client_informations`
--
ALTER TABLE `cams_client_informations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_client_needs`
--
ALTER TABLE `cams_client_needs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_client_progresses`
--
ALTER TABLE `cams_client_progresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_client_referrals`
--
ALTER TABLE `cams_client_referrals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_client_vulnerability_codes`
--
ALTER TABLE `cams_client_vulnerability_codes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_countries`
--
ALTER TABLE `cams_countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `cams_departments`
--
ALTER TABLE `cams_departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_districts`
--
ALTER TABLE `cams_districts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cams_dump_cash_distributions`
--
ALTER TABLE `cams_dump_cash_distributions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_dump_clients`
--
ALTER TABLE `cams_dump_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_dump_items_disbursements`
--
ALTER TABLE `cams_dump_items_disbursements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_forms`
--
ALTER TABLE `cams_forms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_forms_fields`
--
ALTER TABLE `cams_forms_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_forms_group_fields`
--
ALTER TABLE `cams_forms_group_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_functional_assessments`
--
ALTER TABLE `cams_functional_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_hand_simulations`
--
ALTER TABLE `cams_hand_simulations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_home_assessments`
--
ALTER TABLE `cams_home_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_houshold_profiles`
--
ALTER TABLE `cams_houshold_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_inclusion_assessments`
--
ALTER TABLE `cams_inclusion_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_inclusion_medical_histories`
--
ALTER TABLE `cams_inclusion_medical_histories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_inventory_receiveds`
--
ALTER TABLE `cams_inventory_receiveds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_items_categories`
--
ALTER TABLE `cams_items_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_items_disbursements`
--
ALTER TABLE `cams_items_disbursements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_items_disbursement_items`
--
ALTER TABLE `cams_items_disbursement_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_items_inventories`
--
ALTER TABLE `cams_items_inventories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_item_receiveds`
--
ALTER TABLE `cams_item_receiveds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_i_a_cognitions`
--
ALTER TABLE `cams_i_a_cognitions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_i_a_motor_skills`
--
ALTER TABLE `cams_i_a_motor_skills`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_i_a_sensory_abilities`
--
ALTER TABLE `cams_i_a_sensory_abilities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_migrations`
--
ALTER TABLE `cams_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1358;
--
-- AUTO_INCREMENT for table `cams_mpc_contexts`
--
ALTER TABLE `cams_mpc_contexts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_long_rehabs`
--
ALTER TABLE `cams_mpc_long_rehabs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_as`
--
ALTER TABLE `cams_mpc_part_as`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_a_moving_patterns`
--
ALTER TABLE `cams_mpc_part_a_moving_patterns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_a_postures`
--
ALTER TABLE `cams_mpc_part_a_postures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_a_rom_lowers`
--
ALTER TABLE `cams_mpc_part_a_rom_lowers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_a_rom_uppers`
--
ALTER TABLE `cams_mpc_part_a_rom_uppers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_bs`
--
ALTER TABLE `cams_mpc_part_bs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_b_body_senses`
--
ALTER TABLE `cams_mpc_part_b_body_senses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_cs`
--
ALTER TABLE `cams_mpc_part_cs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_ds`
--
ALTER TABLE `cams_mpc_part_ds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_es`
--
ALTER TABLE `cams_mpc_part_es`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_part_fs`
--
ALTER TABLE `cams_mpc_part_fs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_performance_areas`
--
ALTER TABLE `cams_mpc_performance_areas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_short_rehabs`
--
ALTER TABLE `cams_mpc_short_rehabs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_mpc_swots`
--
ALTER TABLE `cams_mpc_swots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_needs`
--
ALTER TABLE `cams_needs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `cams_need_categories`
--
ALTER TABLE `cams_need_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cams_origins`
--
ALTER TABLE `cams_origins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_paediatric_assessments`
--
ALTER TABLE `cams_paediatric_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_paediatric_assessment_histories`
--
ALTER TABLE `cams_paediatric_assessment_histories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_paediatric_child_growths`
--
ALTER TABLE `cams_paediatric_child_growths`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_paediatric_child_histories`
--
ALTER TABLE `cams_paediatric_child_histories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_paediatric_child_inspections`
--
ALTER TABLE `cams_paediatric_child_inspections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_paediatric_child_inspection_results`
--
ALTER TABLE `cams_paediatric_child_inspection_results`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_permissions`
--
ALTER TABLE `cams_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `cams_physical_assessments`
--
ALTER TABLE `cams_physical_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_post_cash_assessments`
--
ALTER TABLE `cams_post_cash_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_progress_notes`
--
ALTER TABLE `cams_progress_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_p_c_cash_usages`
--
ALTER TABLE `cams_p_c_cash_usages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_p_c_cash_usage_categories`
--
ALTER TABLE `cams_p_c_cash_usage_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_p_c_cash_withdrawals`
--
ALTER TABLE `cams_p_c_cash_withdrawals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_p_c_categories`
--
ALTER TABLE `cams_p_c_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `cams_p_c_communal_relations`
--
ALTER TABLE `cams_p_c_communal_relations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_p_c_demographic_details`
--
ALTER TABLE `cams_p_c_demographic_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_p_c_physically_receiving_cashes`
--
ALTER TABLE `cams_p_c_physically_receiving_cashes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_p_s_n_codes`
--
ALTER TABLE `cams_p_s_n_codes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_p_s_n_code_categories`
--
ALTER TABLE `cams_p_s_n_code_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_receiving_agencies`
--
ALTER TABLE `cams_receiving_agencies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_referral_reasons`
--
ALTER TABLE `cams_referral_reasons`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_referral_service_requesteds`
--
ALTER TABLE `cams_referral_service_requesteds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_referring_agencies`
--
ALTER TABLE `cams_referring_agencies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_regions`
--
ALTER TABLE `cams_regions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `cams_rehabilitations`
--
ALTER TABLE `cams_rehabilitations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_requested_services`
--
ALTER TABLE `cams_requested_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_roles`
--
ALTER TABLE `cams_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `cams_take_measurements`
--
ALTER TABLE `cams_take_measurements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_users`
--
ALTER TABLE `cams_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `cams_vulnerability_assessments`
--
ALTER TABLE `cams_vulnerability_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cams_wheel_chair_assessments`
--
ALTER TABLE `cams_wheel_chair_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cams_assessment_economic_situations`
--
ALTER TABLE `cams_assessment_economic_situations`
  ADD CONSTRAINT `assessment_economic_situations_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_houshold_profiles`
--
ALTER TABLE `cams_assessment_houshold_profiles`
  ADD CONSTRAINT `assessment_houshold_profiles_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_impairment_types`
--
ALTER TABLE `cams_assessment_impairment_types`
  ADD CONSTRAINT `assessment_impairment_types_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_independence_participations`
--
ALTER TABLE `cams_assessment_independence_participations`
  ADD CONSTRAINT `assessment_independence_participations_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_interviews`
--
ALTER TABLE `cams_assessment_interviews`
  ADD CONSTRAINT `assessment_interviews_wc_assessment_id_foreign` FOREIGN KEY (`wc_assessment_id`) REFERENCES `cams_wheel_chair_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_item_needs`
--
ALTER TABLE `cams_assessment_item_needs`
  ADD CONSTRAINT `assessment_item_needs_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_nutritions`
--
ALTER TABLE `cams_assessment_nutritions`
  ADD CONSTRAINT `assessment_nutritions_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_protections`
--
ALTER TABLE `cams_assessment_protections`
  ADD CONSTRAINT `assessment_protections_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_psychosocials`
--
ALTER TABLE `cams_assessment_psychosocials`
  ADD CONSTRAINT `assessment_psychosocials_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_referrals`
--
ALTER TABLE `cams_assessment_referrals`
  ADD CONSTRAINT `assessment_referrals_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_assessment_vulnerability_types`
--
ALTER TABLE `cams_assessment_vulnerability_types`
  ADD CONSTRAINT `assessment_vulnerability_types_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_camps`
--
ALTER TABLE `cams_camps`
  ADD CONSTRAINT `camps_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `cams_districts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `camps_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `cams_regions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_cash_provisions`
--
ALTER TABLE `cams_cash_provisions`
  ADD CONSTRAINT `cash_provisions_activity_id_foreign` FOREIGN KEY (`activity_id`) REFERENCES `cams_budget_activities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cash_provisions_camp_id_foreign` FOREIGN KEY (`camp_id`) REFERENCES `cams_camps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_cash_provision_clients`
--
ALTER TABLE `cams_cash_provision_clients`
  ADD CONSTRAINT `cash_provision_clients_activity_id_foreign` FOREIGN KEY (`activity_id`) REFERENCES `cams_budget_activities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cash_provision_clients_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cash_provision_clients_provision_id_foreign` FOREIGN KEY (`provision_id`) REFERENCES `cams_cash_provisions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_clients`
--
ALTER TABLE `cams_clients`
  ADD CONSTRAINT `clients_camp_id_foreign` FOREIGN KEY (`camp_id`) REFERENCES `cams_camps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `clients_origin_id_foreign` FOREIGN KEY (`origin_id`) REFERENCES `cams_origins` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `cams_client_cases`
--
ALTER TABLE `cams_client_cases`
  ADD CONSTRAINT `client_cases_camp_id_foreign` FOREIGN KEY (`camp_id`) REFERENCES `cams_camps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `client_cases_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_client_informations`
--
ALTER TABLE `cams_client_informations`
  ADD CONSTRAINT `client_informations_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `cams_client_referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_client_needs`
--
ALTER TABLE `cams_client_needs`
  ADD CONSTRAINT `client_needs_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_vulnerability_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `client_needs_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `client_needs_need_id_foreign` FOREIGN KEY (`need_id`) REFERENCES `cams_needs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_client_progresses`
--
ALTER TABLE `cams_client_progresses`
  ADD CONSTRAINT `client_progresses_camp_id_foreign` FOREIGN KEY (`camp_id`) REFERENCES `cams_camps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `client_progresses_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_client_referrals`
--
ALTER TABLE `cams_client_referrals`
  ADD CONSTRAINT `client_referrals_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_client_vulnerability_codes`
--
ALTER TABLE `cams_client_vulnerability_codes`
  ADD CONSTRAINT `client_vulnerability_codes_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_districts`
--
ALTER TABLE `cams_districts`
  ADD CONSTRAINT `districts_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `cams_regions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_functional_assessments`
--
ALTER TABLE `cams_functional_assessments`
  ADD CONSTRAINT `functional_assessments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_hand_simulations`
--
ALTER TABLE `cams_hand_simulations`
  ADD CONSTRAINT `hand_simulations_p_assessment_id_foreign` FOREIGN KEY (`p_assessment_id`) REFERENCES `cams_physical_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_home_assessments`
--
ALTER TABLE `cams_home_assessments`
  ADD CONSTRAINT `home_assessments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_houshold_profiles`
--
ALTER TABLE `cams_houshold_profiles`
  ADD CONSTRAINT `houshold_profiles_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_inclusion_assessments`
--
ALTER TABLE `cams_inclusion_assessments`
  ADD CONSTRAINT `inclusion_assessments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_inclusion_medical_histories`
--
ALTER TABLE `cams_inclusion_medical_histories`
  ADD CONSTRAINT `inclusion_medical_histories_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_items_disbursements`
--
ALTER TABLE `cams_items_disbursements`
  ADD CONSTRAINT `items_disbursements_camp_id_foreign` FOREIGN KEY (`camp_id`) REFERENCES `cams_camps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_items_disbursement_items`
--
ALTER TABLE `cams_items_disbursement_items`
  ADD CONSTRAINT `items_disbursement_items_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `items_disbursement_items_distribution_id_foreign` FOREIGN KEY (`distribution_id`) REFERENCES `cams_items_disbursements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `items_disbursement_items_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `cams_items_inventories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_items_inventories`
--
ALTER TABLE `cams_items_inventories`
  ADD CONSTRAINT `items_inventories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `cams_items_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_item_receiveds`
--
ALTER TABLE `cams_item_receiveds`
  ADD CONSTRAINT `item_receiveds_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `cams_items_inventories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `item_receiveds_received_id_foreign` FOREIGN KEY (`received_id`) REFERENCES `cams_inventory_receiveds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_contexts`
--
ALTER TABLE `cams_mpc_contexts`
  ADD CONSTRAINT `mpc_contexts_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_long_rehabs`
--
ALTER TABLE `cams_mpc_long_rehabs`
  ADD CONSTRAINT `mpc_long_rehabs_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_as`
--
ALTER TABLE `cams_mpc_part_as`
  ADD CONSTRAINT `mpc_part_as_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_a_moving_patterns`
--
ALTER TABLE `cams_mpc_part_a_moving_patterns`
  ADD CONSTRAINT `mpc_part_a_moving_patterns_mpc_part_a_id_foreign` FOREIGN KEY (`mpc_part_a_id`) REFERENCES `cams_mpc_part_as` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_a_postures`
--
ALTER TABLE `cams_mpc_part_a_postures`
  ADD CONSTRAINT `mpc_part_a_postures_mpc_part_a_id_foreign` FOREIGN KEY (`mpc_part_a_id`) REFERENCES `cams_mpc_part_as` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_a_rom_lowers`
--
ALTER TABLE `cams_mpc_part_a_rom_lowers`
  ADD CONSTRAINT `mpc_part_a_rom_lowers_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_a_rom_uppers`
--
ALTER TABLE `cams_mpc_part_a_rom_uppers`
  ADD CONSTRAINT `mpc_part_a_rom_uppers_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_bs`
--
ALTER TABLE `cams_mpc_part_bs`
  ADD CONSTRAINT `mpc_part_bs_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_b_body_senses`
--
ALTER TABLE `cams_mpc_part_b_body_senses`
  ADD CONSTRAINT `mpc_part_b_body_senses_mpc_part_b_id_foreign` FOREIGN KEY (`mpc_part_b_id`) REFERENCES `cams_mpc_part_bs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_cs`
--
ALTER TABLE `cams_mpc_part_cs`
  ADD CONSTRAINT `mpc_part_cs_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_ds`
--
ALTER TABLE `cams_mpc_part_ds`
  ADD CONSTRAINT `mpc_part_ds_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_es`
--
ALTER TABLE `cams_mpc_part_es`
  ADD CONSTRAINT `mpc_part_es_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_part_fs`
--
ALTER TABLE `cams_mpc_part_fs`
  ADD CONSTRAINT `mpc_part_fs_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_performance_areas`
--
ALTER TABLE `cams_mpc_performance_areas`
  ADD CONSTRAINT `mpc_performance_areas_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_short_rehabs`
--
ALTER TABLE `cams_mpc_short_rehabs`
  ADD CONSTRAINT `mpc_short_rehabs_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_mpc_swots`
--
ALTER TABLE `cams_mpc_swots`
  ADD CONSTRAINT `mpc_swots_incl_assessment_id_foreign` FOREIGN KEY (`incl_assessment_id`) REFERENCES `cams_inclusion_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_needs`
--
ALTER TABLE `cams_needs`
  ADD CONSTRAINT `needs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `cams_need_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_paediatric_assessments`
--
ALTER TABLE `cams_paediatric_assessments`
  ADD CONSTRAINT `paediatric_assessments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_paediatric_assessment_histories`
--
ALTER TABLE `cams_paediatric_assessment_histories`
  ADD CONSTRAINT `paediatric_assessment_histories_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_paediatric_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_paediatric_child_growths`
--
ALTER TABLE `cams_paediatric_child_growths`
  ADD CONSTRAINT `paediatric_child_growths_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_paediatric_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_paediatric_child_histories`
--
ALTER TABLE `cams_paediatric_child_histories`
  ADD CONSTRAINT `paediatric_child_histories_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_paediatric_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_paediatric_child_inspections`
--
ALTER TABLE `cams_paediatric_child_inspections`
  ADD CONSTRAINT `paediatric_child_inspections_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_paediatric_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_paediatric_child_inspection_results`
--
ALTER TABLE `cams_paediatric_child_inspection_results`
  ADD CONSTRAINT `paediatric_child_inspection_results_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_paediatric_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_permission_role`
--
ALTER TABLE `cams_permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `cams_permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `cams_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_physical_assessments`
--
ALTER TABLE `cams_physical_assessments`
  ADD CONSTRAINT `physical_assessments_wc_assessment_id_foreign` FOREIGN KEY (`wc_assessment_id`) REFERENCES `cams_wheel_chair_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_post_cash_assessments`
--
ALTER TABLE `cams_post_cash_assessments`
  ADD CONSTRAINT `post_cash_assessments_camp_id_foreign` FOREIGN KEY (`camp_id`) REFERENCES `cams_camps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `post_cash_assessments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `post_cash_assessments_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `cams_districts` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `cams_progress_notes`
--
ALTER TABLE `cams_progress_notes`
  ADD CONSTRAINT `progress_notes_camp_id_foreign` FOREIGN KEY (`camp_id`) REFERENCES `cams_camps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `progress_notes_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_p_c_cash_usages`
--
ALTER TABLE `cams_p_c_cash_usages`
  ADD CONSTRAINT `p_c_cash_usages_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_post_cash_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_p_c_cash_usage_categories`
--
ALTER TABLE `cams_p_c_cash_usage_categories`
  ADD CONSTRAINT `p_c_cash_usage_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `cams_p_c_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `p_c_cash_usage_categories_usage_id_foreign` FOREIGN KEY (`usage_id`) REFERENCES `cams_p_c_cash_usages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_p_c_cash_withdrawals`
--
ALTER TABLE `cams_p_c_cash_withdrawals`
  ADD CONSTRAINT `p_c_cash_withdrawals_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_post_cash_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_p_c_communal_relations`
--
ALTER TABLE `cams_p_c_communal_relations`
  ADD CONSTRAINT `p_c_communal_relations_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_post_cash_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_p_c_demographic_details`
--
ALTER TABLE `cams_p_c_demographic_details`
  ADD CONSTRAINT `p_c_demographic_details_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_post_cash_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_p_c_physically_receiving_cashes`
--
ALTER TABLE `cams_p_c_physically_receiving_cashes`
  ADD CONSTRAINT `p_c_physically_receiving_cashes_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `cams_post_cash_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_p_s_n_codes`
--
ALTER TABLE `cams_p_s_n_codes`
  ADD CONSTRAINT `p_s_n_codes_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `cams_p_s_n_code_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_receiving_agencies`
--
ALTER TABLE `cams_receiving_agencies`
  ADD CONSTRAINT `receiving_agencies_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `cams_client_referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_referral_reasons`
--
ALTER TABLE `cams_referral_reasons`
  ADD CONSTRAINT `referral_reasons_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `cams_client_referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_referral_service_requesteds`
--
ALTER TABLE `cams_referral_service_requesteds`
  ADD CONSTRAINT `referral_service_requesteds_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `cams_client_referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_referring_agencies`
--
ALTER TABLE `cams_referring_agencies`
  ADD CONSTRAINT `referring_agencies_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `cams_client_referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_regions`
--
ALTER TABLE `cams_regions`
  ADD CONSTRAINT `regions_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `cams_countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_requested_services`
--
ALTER TABLE `cams_requested_services`
  ADD CONSTRAINT `requested_services_requested_id_foreign` FOREIGN KEY (`requested_id`) REFERENCES `cams_referral_service_requesteds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_role_user`
--
ALTER TABLE `cams_role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `cams_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `cams_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_take_measurements`
--
ALTER TABLE `cams_take_measurements`
  ADD CONSTRAINT `take_measurements_p_assessment_id_foreign` FOREIGN KEY (`p_assessment_id`) REFERENCES `cams_physical_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_vulnerability_assessments`
--
ALTER TABLE `cams_vulnerability_assessments`
  ADD CONSTRAINT `vulnerability_assessments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cams_wheel_chair_assessments`
--
ALTER TABLE `cams_wheel_chair_assessments`
  ADD CONSTRAINT `wheel_chair_assessments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `cams_clients` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
